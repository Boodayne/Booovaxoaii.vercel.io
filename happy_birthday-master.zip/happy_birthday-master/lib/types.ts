export type TimelineItem = {
  time: string;
  description: string;
}
